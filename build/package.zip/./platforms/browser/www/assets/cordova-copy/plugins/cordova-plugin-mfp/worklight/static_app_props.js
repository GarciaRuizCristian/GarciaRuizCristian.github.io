// This is a generated file. Do not edit. See application-descriptor.xml.
// WLClient configuration variables.
console.log("Running static_app_props.js...");
var WL = WL ? WL : {};
WL.StaticAppProps = { APP_ID: 'com.ionicframework.hipracrm376280',
  APP_VERSION: '0.0.1',
  WORKLIGHT_PLATFORM_VERSION: '8.0.0.00-20170218-003050',
  WORKLIGHT_NATIVE_VERSION: '3033571650',
  LANGUAGE_PREFERENCES: 'en',
  ENVIRONMENT: 'preview',
  PREVIEW_ENVIRONMENT: 'iphone',
  PREVIEW_ROOT_URL: 'http://192.168.0.84:9080/mfp/',
  APP_SERVICES_URL: '/mfp/apps/services/',
  POSTFIX_APP_SERVICES_URL: '/mfp/apps/services/',
  WORKLIGHT_ROOT_URL: '/mfp/apps/services/api/hipracrm/iphone/',
  POSTFIX_WORKLIGHT_ROOT_URL: '/mfp/apps/services/api/hipracrm/iphone/',
  APP_DISPLAY_NAME: 'hipracrm',
  LOGIN_DISPLAY_TYPE: 'embedded',
  mfpClientCustomInit: false,
  MESSAGES_DIR: 'plugins\\cordova-plugin-mfp\\worklight\\messages' };